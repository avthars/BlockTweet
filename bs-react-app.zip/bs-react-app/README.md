# React.js boilerplate with Blockstack

This was based originally off this repo: [MERN-Boilerplate](https://github.com/keithweaver/MERN-boilerplate). It's a basic React.js app for a starting point. For more information about [Blockstack](https://blockstack.org/) and [Blockstack.js](https://github.com/blockstack/blockstack.js).

## Setup

```
npm install
```


## Running

```
npm run start
```

It will be running at http://localhost:2048
